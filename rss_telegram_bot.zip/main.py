import time
import requests
import feedparser

# Configuration
TELEGRAM_TOKEN = "7568250697:AAFJJcW-f5xp9zrJnYwIlfCI1ApVmPUytLY"
TELEGRAM_CHAT_ID = "-1002527502531"
RSS_URL = "https://nitter.privacydev.net/elonmusk/rss"  # Instance Nitter fonctionnelle
CHECK_INTERVAL = 60  # en secondes

last_entry_id = None

def send_telegram_message(text):
    url = f"https://api.telegram.org/bot{TELEGRAM_TOKEN}/sendMessage"
    payload = {
        "chat_id": TELEGRAM_CHAT_ID,
        "text": text,
        "parse_mode": "HTML"
    }
    try:
        requests.post(url, data=payload)
    except Exception as e:
        print(f"Erreur en envoyant le message Telegram: {e}")

while True:
    try:
        feed = feedparser.parse(RSS_URL)
        if feed.entries:
            latest_entry = feed.entries[0]
            if latest_entry.id != last_entry_id:
                message = f"🆕 Nouveau post ou changement détecté sur le profil X d'Elon Musk:

{latest_entry.title}
{latest_entry.link}"
                send_telegram_message(message)
                last_entry_id = latest_entry.id
    except Exception as e:
        print(f"Erreur lors de l'analyse RSS: {e}")

    time.sleep(CHECK_INTERVAL)
